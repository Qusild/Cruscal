#include "myvector.h"

myVector::myVector()
{
    sizer = 0;
}

bool myVector::isEmpty()
{
    if (sizer==0)
        return true;
    else return false;
}

void myVector::push_back(connector input)
{
    connector *temp;
    temp = new connector[sizer+1];
    if (!isEmpty())
        for (int i =0;i<sizer;i++)
            temp[i] = vector[i];
    temp[sizer]=input;
    if (!isEmpty())
        delete[] vector;
    sizer++;
    vector = temp;
}

void myVector::pop_back()
{
    if (!isEmpty())
    {
        connector *temp;
        temp = new connector[sizer-1];
        for (int i =0;i<sizer-1;i++)
            temp[i] = vector[i];
        sizer--;
        delete[] vector;
        vector = temp;
    }
}

void myVector::pop_first()
{
    if (!isEmpty())
    {
        connector *temp;
        temp = new connector[sizer-1];
        for (int i =1;i<sizer;i++)
            temp[i-1] = vector[i];
        sizer--;
        delete[] vector;
        vector = temp;
    }
}

int myVector::size()
{
    return sizer;
}

void myVector::clear()
{
    delete[] vector;
    sizer = 0;
}

connector& myVector::operator [] (int index)
{
 return vector[index];
}

#include "mystringlist.h"
#include <QStringList>
myStringList::myStringList()
{
    size = 0;
}


int myStringList::getSize()
{
    return size;
}

void myStringList::operator<<(QString input)
{
    QString *temp;
    temp = new QString[size+1];
    for (int i=0;i<size;i++)
    {
        temp[i] = StringList[i];
    }
    temp[size] = input;
    size++;
    delete[] StringList;
    StringList = temp;
}

void myStringList::pop_back()
{
    QString *temp;
    temp = new QString[size-1];
    for (int i=0;i<size-1;i++)
    {
        temp[i] = StringList[i];
    }
    size--;
    delete[] StringList;
    StringList=temp;
}

QString& myStringList::operator [](int input)
{
    return StringList[input];
}

void myStringList::pop_front()
{
    QString *temp;
    temp = new QString[size-1];
    for (int i=1;i<size;i++)
    {
        temp[i-1] = StringList[i];
    }
    size--;
    delete[] StringList;
    StringList=temp;
}

void myStringList::clear()
{
    delete[] StringList;
    size = 0;
}

bool myStringList::contains(QString input)
{
    for (int i =0;i<size;i++)
        if (StringList[i]==input)
            return true;
    else return false;
}

bool myStringList::isEmpty()
{
    if (size>0)
        return false;
    else return true;
}

void myStringList::operator = (QStringList input)
{
    size = input.size();
    delete[] StringList;
    StringList = new QString[size];
    for (int i =0;i<size;i++)
        StringList[i] = input[i];
}

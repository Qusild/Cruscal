#ifndef MYSTRINGLIST_H
#define MYSTRINGLIST_H
#include <QString>

class myStringList
{
public:
    myStringList();
    void operator << (QString input);
    int getSize();
    void pop_front();
    void pop_back();
    QString& operator [] (int index);
    void clear();
    bool contains(QString input);
    bool isEmpty();
    void operator = (QStringList input);
private:
    QString *StringList;
    int size;
};

#endif // MYSTRINGLIST_H

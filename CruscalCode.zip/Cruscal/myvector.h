#ifndef MYVECTOR_H
#define MYVECTOR_H
#include "connector.h"

class myVector
{
public:
    myVector();
    void push_back(connector input);
    void pop_back();
    void pop_first();
    int size();
    bool isEmpty();
    connector *vector;
    void clear();
    connector& operator [] (int index);
private:
    int sizer;
};


#endif // MYVECTOR_H

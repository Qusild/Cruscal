#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include "connector.h"
#include <vector>
#include "myvector.h"
#include "mystringlist.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr, QString *EdgeList = nullptr);
    ~MainWindow();
    bool nodeExists(QString nodeName);
    bool alreadyExists(connector newEdge);
    void mergeSortImpl(int s, int e, connector * temp);
    void mergeSort();
    myVector<connector> findCarcase();
    int nodeNumber(QString nodeName);
    int findNode(QString nodeName, int* nodeList);
private:
    Ui::MainWindow *ui;
    QPushButton *fileOpener;
    QPushButton *tester;
    QString fileName;
    myStringList nodeNames;
    QString *edgeList;
    int **matrixView;
    myVector<connector> edges;
private slots:
    void connectFile();
    void showGraph();
    void textToGraph();
    void handInput();
    void showMatrix();
    void DFS();
    void BFS();
signals:
    void DFSshow(int **matrixView, myStringList nodeNames, int nodeNum);
    void BFSshow(int **matrixView, myStringList nodeNames, int nodeNum);
    void startInput();
    void openMatrix(int **matrixView, myStringList nodeNames);
};
#endif // MAINWINDOW_H

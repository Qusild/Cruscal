#include "mystringlist.h"
#include <QStringList>
myStringList::myStringList()
{
    sizer = 0;
}


int myStringList::size()
{
    return sizer;
}

void myStringList::operator<<(QString input)
{
    QString *temp;
    temp = new QString[sizer+1];
    for (int i=0;i<sizer;i++)
    {
        temp[i] = StringList[i];
    }
    temp[sizer] = input;
    if (!isEmpty())
       delete[] StringList;
    sizer++;
    StringList = temp;
}

void myStringList::pop_back()
{
    QString *temp;
    temp = new QString[sizer-1];
    for (int i=0;i<sizer-1;i++)
    {
        temp[i] = StringList[i];
    }
    sizer--;
    delete[] StringList;
    StringList=temp;
}

QString& myStringList::operator [](int input)
{
    return StringList[input];
}

void myStringList::pop_front()
{
    QString *temp;
    temp = new QString[sizer-1];
    for (int i=1;i<sizer;i++)
    {
        temp[i-1] = StringList[i];
    }
    sizer--;

    delete[] StringList;
    StringList=temp;
}

void myStringList::clear()
{
    if (!isEmpty())
        delete[] StringList;
    sizer = 0;
}

bool myStringList::contains(QString input)
{
    for (int i =0;i<sizer;i++)
        if (StringList[i]==input)
            return true;
    return false;
}

bool myStringList::isEmpty()
{
    if (sizer>0)
        return false;
    else return true;
}

void myStringList::operator = (QStringList input)
{
    if (!isEmpty())
        delete[] StringList;
    sizer = input.size();
    StringList = new QString[sizer];
    for (int i =0;i<sizer;i++)
        StringList[i] = input[i];
}

QStringList myStringList::toQStringList()
{
    QStringList input;
    for (int i =0;i<size();i++)
        input<<StringList[i];
    return input;
}

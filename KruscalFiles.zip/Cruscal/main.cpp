#include "mainwindow.h"
#include "textinput.h"
#include <QApplication>
#include "matrixviewer.h"
#include "mystringlist.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QString edgeList;
    MainWindow w(nullptr, &edgeList);
    TextInput t(nullptr,&edgeList);
    matrixViewer m;
    //Подключение всех кнопок, что вызывают открытие других кнопок
    QObject::connect(&w, SIGNAL(startInput()), &t, SLOT(show()));
    QObject::connect(&w, SIGNAL(startInput()), &t, SLOT(getText()));
    QObject::connect(&t, SIGNAL(transfText()), &w, SLOT(textToGraph()));
    QObject::connect(&w, SIGNAL(openMatrix(int **, myStringList)), &m, SLOT(showMatrix(int **, myStringList)));
    QObject::connect(&w, SIGNAL(openMatrix(int **, myStringList)), &m, SLOT(show()));
    QObject::connect(&w, SIGNAL(DFSshow(int **, myStringList , int )), &m, SLOT(DFS(int **, myStringList , int )));
    QObject::connect(&w, SIGNAL(DFSshow(int **, myStringList , int )), &m, SLOT(show()));
    QObject::connect(&w, SIGNAL(BFSshow(int **, myStringList , int )), &m, SLOT(BFS(int **, myStringList , int )));
    QObject::connect(&w, SIGNAL(BFSshow(int **, myStringList , int )), &m, SLOT(show()));
    w.show();
    return a.exec();
}

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QFileDialog>
#include <QPushButton>
#include "connector.h"
#include <vector>
#include <QStandardItemModel>
MainWindow::MainWindow(QWidget *parent, QString *EdgeList)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    edgeList=EdgeList;
    fileOpener = ui->pushButton;
    tester = ui->pushButton_2;
    //Подсоединение всех кнопок к соответствующим функциям
    connect (fileOpener, SIGNAL(clicked()), this, SLOT(connectFile()));
    connect (tester, SIGNAL(clicked()), this, SLOT(showGraph()));
    connect (ui->pushButton_4, SIGNAL(clicked()), this, SLOT(handInput()));
    connect (ui->BFS, SIGNAL(clicked()), this, SLOT(BFS()));
    connect (ui->DFS, SIGNAL(clicked()), this, SLOT(DFS()));
    connect (ui->matrix, SIGNAL(clicked()), this, SLOT(showMatrix()));
}

void MainWindow::DFS()
{
    int num;
    num = nodeNumber(ui->textEdit->toPlainText());
    if (nodeNames.size()==0)
        return;
    //Сигнал вызова отдельного окна, в котором показывается глубокий обход графа
    emit DFSshow(matrixView, nodeNames, num);
}

void MainWindow::BFS()
{
    int num;
    num = nodeNumber(ui->textEdit->toPlainText());
    if (nodeNames.size()==0)
        return;
    //Сигнал вызова отдельного окна, в котором показывается широкий обход графа
    emit BFSshow(matrixView, nodeNames, num);
}

void MainWindow::handInput()
{
    //Сигнал начала ввода ребер графа в ручном виде
    emit startInput();
}

void MainWindow::showMatrix()
{
    //Сигнал вызова отдельного окна, в котором отображается матрица смежности графа
    emit openMatrix(matrixView, nodeNames);
}

//Функция проверяет каждый элемент string'a, если все элементы - цифры, то строка считается числом
bool isNumber(QString input)
{
    bool digits[input.size()];
    for (int i=0;i<input.size();i++)
        digits[i] = input[i].isDigit();
    for (int i=0;i<input.size();i++)
        if (!digits[i])
            return false;
    return true;
}

void MainWindow::mergeSortImpl(int s, int e, connector * temp)
{
    int m;
    if (s<e)
    {
        m = (s+e)/2;
        mergeSortImpl(s, m, temp);
        mergeSortImpl(m+1,e, temp);
        int k = s;
        for (int i = s, j= m+1 ;i<=m||j<=e;)
        {
            if (j>e||(i<=m && (edges[i].weight<edges[j].weight)))
            {
                temp[k] = edges[i];
                i++;
            }
            else
            {
                temp[k] = edges[j];
                j++;
            }
            k++;
        }
        for (int i = s;i<=e;i++)
        {
            edges[i] = temp[i];
        }
    }
}

void MainWindow::mergeSort()
{
    connector * temp;
    temp = new connector[edges.size()];
    mergeSortImpl(0, edges.size()-1, temp);
    delete[] temp;
}

//Функция возвращает номер вершины графа из соответсвующего списка
//ВАЖНО:Вершины графа не сортируются и входят в список в порядке их появления при вводе
int MainWindow::nodeNumber(QString nodeName)
{
    for (int i=0;i<nodeNames.size();i++)
        if (nodeName == nodeNames[i])
            return i;
    return NULL;
}

//Функция предотвращает создание создание одинаковых ребер
//ВАЖНО:Граф считается неориентированным, так что бракуется повторение пары вершин в любом порядке
bool MainWindow::alreadyExists(connector newEdge)
{
    for (int i = 0;i<edges.size();i++)
        if ((edges[i].output==newEdge.output)&&(edges[i].input==newEdge.input))
            return true;
        else if ((edges[i].output==newEdge.input)&&(edges[i].input==newEdge.output))
            return true;
    return false;
}

//Функция проверяет входит ли вершина в список вершин
//По сути функция просто повторяет метод contains, но так красивее получается
bool MainWindow::nodeExists(QString nodeName)
{
    return nodeNames.contains(nodeName);
}

void MainWindow::connectFile()
{
    //Очистка всех вершин и ребер. Нужна в случае, если пользователь подключает новый файл
    nodeNames.clear();
    if (!edges.isEmpty())
    edges.clear();
    //Открытие диалогового окна, в котором можно выбрать необходимый файл с вершинами графа
    //ВАЖНО:Отображаются только .txt файлы
    fileName = QFileDialog::getOpenFileName(this,tr("Выберит файл"),"C:/", tr("Data (*txt)"));
    QFile file(fileName);
    QTextStream nodeReader(&file);
    //Открытие файла в режиме чтения текста
    if ( !file.open(QFile::ReadOnly | QFile::Text) )
    {
        qDebug() << "File not exists";
    }
    myStringList liner;
    QString line;
    //Чтение до конца файла
    while (!nodeReader.atEnd())
    {
        //Чтение одной строки
        line  = nodeReader.readLine();
        //Разбитие строки на подстроки по пробелам
        for (QString item : line.split(" "))
        {
            //Если подстрока не является числом
            if (!isNumber(item))
                //И не была добавлена в список вершин ранее
                if (!nodeExists(item))
                    //Она добавляется в список вершин
                    nodeNames<<item;
            //Проверка на соответствие условиям курсовика (Максимум - 50 вершин)
            if (nodeNames.size()>50)
            {
             qDebug()<<"ERROR: TO much Nodes";
                return;
            }
        }
    }
    //Закрытие файла
    file.close();
    //Создание нулевой матрицы смежности
    matrixView = new int *[nodeNames.size()];
    for (int i =0;i<nodeNames.size();i++)
        matrixView[i] = new int[nodeNames.size()];
    for (int i =0;i<nodeNames.size();i++)
        for (int j =0;j<nodeNames.size();j++)
            matrixView[i][j]=0;
    //Повторное открытие файла для чтения рёбер графа
    QTextStream edgeReader(&file);
    if ( !file.open(QFile::ReadOnly | QFile::Text) )
    {
        qDebug() << "File not exists";
    }
    while (!edgeReader.atEnd())
    {
        line = edgeReader.readLine();
        for (QString item : line.split(" "))
        {
            liner<<item;
            if (liner.size()==3)
            {
                connector edge(liner[0],liner[1],liner[2]);
                //Редактирование матрицы смежности
                //ВАЖНО:Рёбра считаются неориентироваными, так что в матрице делается 2 записи симметрично главной оси
                matrixView[nodeNumber(liner[0])][nodeNumber(liner[1])] = liner[2].toInt();
                matrixView[nodeNumber(liner[1])][nodeNumber(liner[0])] = liner[2].toInt();
                if (alreadyExists(edge))
                {
                    qDebug()<<"ERROR: edges repeated";
                    return;
                }
                liner.clear();
                //Ребро попадает в вектор рёбер
                edges.push_back(edge);
            }
        }

    }
    file.close();
    return;
}


//Функция находит вершину в списке КС и возвращает КС
int MainWindow::findNode(QString nodeName, int *nodeList)
{
    while(nodeList[nodeNumber(nodeName)]!=nodeNumber(nodeName))
        nodeName=nodeNames[nodeList[nodeNumber(nodeName)]];
    return nodeNumber(nodeName);
}


//Функция находит каркас (Минимальное остовное дерево)
myVector<connector> MainWindow::findCarcase()
{
    int *nodeList, totalWeight = 0;
    myVector<connector> carcaseEdges;
    nodeList = new int[nodeNames.size()];
    //Инициализация списка КС, пока каждая вершина находится в отдельной КС
    for (int i =0;i<nodeNames.size();i++)
    {
        nodeList[i] = i;
    }
    for (int i =0;i<edges.size();i++)
    {
        //Если 2 связаные вершины не находятся в одной КС
        if (findNode(edges[i].output,nodeList)!=findNode(edges[i].input,nodeList))
        {
            //Младшей (Вершине, которая вошла в список вершин позже) вершине присваевается КС старшей
            if (nodeNumber(edges[i].input)>nodeNumber(edges[i].output))
                nodeList[nodeNumber(edges[i].input)] = nodeNumber(edges[i].output);
            else nodeList[nodeNumber(edges[i].output)] = nodeNumber(edges[i].input);
            //К общему весу каркаса добавляется вес ребра
            totalWeight += edges[i].weight;
            carcaseEdges.push_back(edges[i]);
        }
    }
    //Очистка и вывод веса в маленькой рамке в правом нижнем углу
    ui->textBrowser->clear();
    ui->textBrowser->append("Вес: ");
    ui->textBrowser->append(QString::number(totalWeight));
    delete[] nodeList;
    return carcaseEdges;
}


//Функция отображает каркас в виде списка рёбер на главном экране приложения
void MainWindow::showGraph()
{
    mergeSort();
    myVector carcaseEdges = findCarcase();
    QStandardItemModel *listPlacer;
    listPlacer = new QStandardItemModel(this);
    ui->tableView->setModel(listPlacer);
    for(int i=0;i<carcaseEdges.size();i++)
    {
        // Добавляем в модель по строке с элементами
        QList<QStandardItem *> standardItemsList;
        // учитываем, что строка разделяется на колонки
            standardItemsList.append(new QStandardItem(carcaseEdges[i].output));
            standardItemsList.append(new QStandardItem(carcaseEdges[i].input));
            QString tmp = QString::number(carcaseEdges[i].weight);
            standardItemsList.append(new QStandardItem(tmp));
        //Построчная вставка полученный значений
        listPlacer->insertRow(listPlacer->rowCount(), standardItemsList);
    }
    myStringList headers;
    headers<<"Вершина";
    headers<<"Вершина";
    headers<<"Вес ребра";
    listPlacer->setHorizontalHeaderLabels(headers.toQStringList());
}


//Функция читает граф, введённый вручную
//ВАЖНО:По большей части повторяет функцию чтения графа из файла
void MainWindow::textToGraph()
{
    nodeNames.clear();
    edges.clear();
    myStringList liner;
    liner = edgeList->split("\n");
    while(!liner.isEmpty())
    {
        myStringList line;
        for (QString item : liner[0].split(" "))
        {
            line<<item;
            if (!isNumber(item))
                if(!nodeExists(item))
                    nodeNames<<item;
            if (nodeNames.size()>50)
            {
                qDebug()<<"ERROR: TO much Nodes";
                return;
            }
        }
        liner.pop_front();
    }
    matrixView = new int *[nodeNames.size()];
    for (int i =0;i<nodeNames.size();i++)
        matrixView[i] = new int[nodeNames.size()];
    for (int i=0;i<nodeNames.size();i++)
        for (int j=0;j<nodeNames.size();j++)
            matrixView[i][j]=0;
    liner = edgeList->split("\n");
    while(!liner.isEmpty())
    {
        myStringList line;
        for (QString item : liner[0].split(" "))
        {
            line<<item;
            if (line.size()==3)
            {
                connector edge(line[0],line[1],line[2]);
                matrixView[nodeNumber(line[0])][nodeNumber(line[1])] = line[2].toInt();
                matrixView[nodeNumber(line[1])][nodeNumber(line[0])] = line[2].toInt();
                if (alreadyExists(edge))
                {
                    qDebug()<<"ERROR: edges repeated";
                    return;
                }
                line.clear();
                edges.push_back(edge);
            }
        }
            liner.pop_front();
    }
}


//Деструктор всего, срабатывает при закрытии приложения
MainWindow::~MainWindow()
{
    delete ui;
    for (int i = 0;i<nodeNames.size();i++)
        delete[] matrixView[i];
    delete[] matrixView;
    delete edgeList;
    delete fileOpener;
    delete tester;
}


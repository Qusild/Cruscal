#ifndef MATRIXVIEWER_H
#define MATRIXVIEWER_H

#include <QDialog>
#include "mystringlist.h"
#include "myvector.h"
namespace Ui {
class matrixViewer;
}

class matrixViewer : public QDialog
{
    Q_OBJECT

public:
    explicit matrixViewer(QWidget *parent = nullptr);
    void visitDFS(int **matrixViewer, int row, int column, bool *visiter, int size);
    void visitBFS(int **matrixViewer, int row, int column, bool *visiter, int size);
    ~matrixViewer();

private:
    Ui::matrixViewer *ui;
    myVector<int> nodeIn, nodeOut;

private slots:
    void showMatrix(int **matrixView, myStringList nodeNames);
    void DFS(int **matrixView, myStringList nodeNames, int nodeNum);
    void BFS(int **matrixView, myStringList nodeNames, int nodeNum);
};

#endif // MATRIXVIEWER_H

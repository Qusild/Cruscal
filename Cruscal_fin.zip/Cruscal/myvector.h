#ifndef MYVECTOR_H
#define MYVECTOR_H
#include "connector.h"
template <typename T>
class myVector
{
public:
    T* vector;myVector()
    {
        sizer = 0;
    }

    bool isEmpty()
    {
        if (sizer==0)
            return true;
        else return false;
    }

    void push_back(T input)
    {
        T *temp;
        temp = new T[sizer+1];
        if (!isEmpty())
            for (int i =0;i<sizer;i++)
                temp[i] = vector[i];
        temp[sizer]=input;
        if (!isEmpty())
            delete[] vector;
        sizer++;
        vector = temp;
    }

    void pop_back()
    {
        if (!isEmpty())
        {
            T *temp;
            temp = new T[sizer-1];
            for (int i =0;i<sizer-1;i++)
                temp[i] = vector[i];
            sizer--;
            delete[] vector;
            vector = temp;
        }
    }

    void pop_first()
    {
        if (!isEmpty())
        {
            T *temp;
            temp = new T[sizer-1];
            for (int i =1;i<sizer;i++)
                temp[i-1] = vector[i];
            sizer--;
            delete[] vector;
            vector = temp;
        }
    }

    int size()
    {
        return sizer;
    }

    void clear()
    {
        if (!isEmpty())
            delete[] vector;
        sizer = 0;
    }

    T& operator [] (int index)
    {
     return vector[index];
    }

private:
    int sizer;
};


#endif // MYVECTOR_H

#ifndef TEXTINPUT_H
#define TEXTINPUT_H

#include <QDialog>

namespace Ui {
class TextInput;
}

class TextInput : public QDialog
{
    Q_OBJECT

public:
    explicit TextInput(QWidget *parent = nullptr, QString *edgeList = nullptr);
    ~TextInput();

private:
    Ui::TextInput *ui;
    QString *edges;
private slots:
    void getText();
    void setText();
signals:
    void transfText();
};

#endif // TEXTINPUT_H

#ifndef MYSTRINGLIST_H
#define MYSTRINGLIST_H
#include <QString>

class myStringList
{
public:
    myStringList();
    void operator << (QString input);
    int size();
    void pop_front();
    void pop_back();
    QString& operator [] (int index);
    void clear();
    bool contains(QString input);
    bool isEmpty();
    void operator = (QStringList input);
    QStringList toQStringList();
private:
    QString *StringList;
    int sizer;
};

#endif // MYSTRINGLIST_H

#include "connector.h"

connector::connector()
{

}

//Просто структура для хранения ребра графа

connector::connector(QString out, QString in, QString weight)
{
    this->output = out;
    this->input = in;
    this->weight = weight.toUInt();
}

#include "textinput.h"
#include "ui_textinput.h"

TextInput::TextInput(QWidget *parent, QString *edgeList) :
    QDialog(parent),
    ui(new Ui::TextInput)
{
    edges = edgeList;
    ui->setupUi(this);
}

void TextInput::getText()
{
    //Подключение кнопки, закрывающей текстовый ввод
    connect(ui->pushButton, SIGNAL(clicked()), this ,SLOT(setText()));
}

void TextInput::setText()
{
    //Преобразование всего ввода в обычный текст
    *edges = ui->textEdit->toPlainText();
    close();
    //Передача текста в основное окно
    //ВАЖНО:Основное окно и окно ввода вершин инициализируется с единым указателем
    //Именно по нему и хранится весь текст ввода вершин
    emit transfText();
}

TextInput::~TextInput()
{
    delete ui;
}

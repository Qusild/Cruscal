/****************************************************************************
** Meta object code from reading C++ file 'matrixviewer.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Cruscal/matrixviewer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'matrixviewer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_matrixViewer_t {
    const uint offsetsAndSize[18];
    char stringdata0[68];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_matrixViewer_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_matrixViewer_t qt_meta_stringdata_matrixViewer = {
    {
QT_MOC_LITERAL(0, 12), // "matrixViewer"
QT_MOC_LITERAL(13, 10), // "showMatrix"
QT_MOC_LITERAL(24, 0), // ""
QT_MOC_LITERAL(25, 5), // "int**"
QT_MOC_LITERAL(31, 10), // "matrixView"
QT_MOC_LITERAL(42, 9), // "nodeNames"
QT_MOC_LITERAL(52, 3), // "DFS"
QT_MOC_LITERAL(56, 7), // "nodeNum"
QT_MOC_LITERAL(64, 3) // "BFS"

    },
    "matrixViewer\0showMatrix\0\0int**\0"
    "matrixView\0nodeNames\0DFS\0nodeNum\0BFS"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_matrixViewer[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   32,    2, 0x08,    1 /* Private */,
       6,    3,   37,    2, 0x08,    4 /* Private */,
       8,    3,   44,    2, 0x08,    8 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::QStringList,    4,    5,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QStringList, QMetaType::Int,    4,    5,    7,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QStringList, QMetaType::Int,    4,    5,    7,

       0        // eod
};

void matrixViewer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<matrixViewer *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showMatrix((*reinterpret_cast< int**(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2]))); break;
        case 1: _t->DFS((*reinterpret_cast< int**(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->BFS((*reinterpret_cast< int**(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        default: ;
        }
    }
}

const QMetaObject matrixViewer::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_matrixViewer.offsetsAndSize,
    qt_meta_data_matrixViewer,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_matrixViewer_t
, QtPrivate::TypeAndForceComplete<matrixViewer, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int * *, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int * *, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int * *, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *matrixViewer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *matrixViewer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_matrixViewer.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int matrixViewer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 3;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

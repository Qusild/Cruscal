#ifndef CONNECTOR_H
#define CONNECTOR_H

#include <QString>

class connector
{
public:
    connector();
    connector(QString out, QString in, QString weight);
    QString output;
    QString input;
    int weight;
};

#endif // CONNECTOR_H

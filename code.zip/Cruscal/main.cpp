#include "mainwindow.h"
#include "textinput.h"
#include <QApplication>
#include "matrixviewer.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QString edgeList;
    MainWindow w(nullptr, &edgeList);
    TextInput t(nullptr,&edgeList);
    matrixViewer m;
    //Подключение всех кнопок, что вызывают открытие других кнопок
    QObject::connect(&w, SIGNAL(startInput()), &t, SLOT(show()));
    QObject::connect(&w, SIGNAL(startInput()), &t, SLOT(getText()));
    QObject::connect(&t, SIGNAL(transfText()), &w, SLOT(textToGraph()));
    QObject::connect(&w, SIGNAL(openMatrix(int **, QStringList)), &m, SLOT(showMatrix(int **, QStringList)));
    QObject::connect(&w, SIGNAL(openMatrix(int **, QStringList)), &m, SLOT(show()));
    QObject::connect(&w, SIGNAL(DFSshow(int **, QStringList , int )), &m, SLOT(DFS(int **, QStringList , int )));
    QObject::connect(&w, SIGNAL(DFSshow(int **, QStringList , int )), &m, SLOT(show()));
    QObject::connect(&w, SIGNAL(BFSshow(int **, QStringList , int )), &m, SLOT(BFS(int **, QStringList , int )));
    QObject::connect(&w, SIGNAL(BFSshow(int **, QStringList , int )), &m, SLOT(show()));
    w.show();
    return a.exec();
}

#ifndef MATRIXVIEWER_H
#define MATRIXVIEWER_H

#include <QDialog>

namespace Ui {
class matrixViewer;
}

class matrixViewer : public QDialog
{
    Q_OBJECT

public:
    explicit matrixViewer(QWidget *parent = nullptr);
    void visitDFS(int **matrixViewer, int row, int column, bool *visiter, int size);
    void visitBFS(int **matrixViewer, int row, int column, bool *visiter, int size);
    ~matrixViewer();

private:
    Ui::matrixViewer *ui;
    std::vector<int> nodeIn, nodeOut;

private slots:
    void showMatrix(int **matrixView, QStringList nodeNames);
    void DFS(int **matrixView, QStringList nodeNames, int nodeNum);
    void BFS(int **matrixView, QStringList nodeNames, int nodeNum);
};

#endif // MATRIXVIEWER_H

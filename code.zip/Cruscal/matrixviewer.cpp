#include "matrixviewer.h"
#include "ui_matrixviewer.h"
#include <QStandardItemModel>
matrixViewer::matrixViewer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::matrixViewer)
{
    ui->setupUi(this);
    connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(close()));
}


//Функция выводит в отдельное окно матрицу смежности графа
void matrixViewer::showMatrix(int **matrixViewer, QStringList nodeNames)
{
    QStandardItemModel *matrixPlacer;
    matrixPlacer = new QStandardItemModel(this);
    ui->tableView->setModel(matrixPlacer);
    ui->tableView->clearSelection();
    for (int i =0;i<nodeNames.size();i++)
    {
        // Добавляем в модель по строке с элементами
        QList<QStandardItem *> standardItemsList;
        // учитываем, что строка разделяется на колонки
        for (int j = 0;j<nodeNames.size();j++)
            standardItemsList.append(new QStandardItem(QString::number(matrixViewer[i][j])));
        //Построчная вставка полученный значений
        matrixPlacer->insertRow(matrixPlacer->rowCount(), standardItemsList);
    }
    //Задает название строк и столбцов матрицы
    matrixPlacer->setHorizontalHeaderLabels(nodeNames);
    matrixPlacer->setVerticalHeaderLabels(nodeNames);
    //Задает минимальную ширину строки матрицы
    for (int i = 0 ;i<nodeNames.size();i++)
    {
        ui->tableView->setColumnWidth(i,1);
    }
}

//Рекурсивный обход графа в глубину
//ВАЖНО:Обход предоставляет 2 списка обхода(на вход и на выход)
void matrixViewer::visitDFS(int **matrixViewer, int row, int column, bool *visiter, int size)
{
    visiter[column] = true;
    nodeIn.push_back(column);
    for (int j =0;j<size;j++)
    {
        if (!visiter[j]&&(matrixViewer[column][j]!=0))
            visitDFS(matrixViewer,column,j, visiter, size);
    }
    nodeOut.push_back(column);
}

//Рекурсивный обход графа в глубину и вывод в отдельном окне
void matrixViewer::DFS(int **matrixViewer, QStringList nodeNames, int nodeNum)
{
    bool *visiter;
    nodeIn.clear();
    nodeOut.clear();
    QStandardItemModel *matrixPlacer;
    matrixPlacer = new QStandardItemModel(this);
    ui->tableView->setModel(matrixPlacer);
    ui->tableView->clearSelection();
    visiter = new bool[nodeNames.size()];
    int size = 0;
    size = nodeNames.size();
    for (int i =0;i<nodeNames.size();i++)
            visiter[i]= false;
    //i- cтрока j- столбец
    visiter[nodeNum] = true;
    nodeIn.push_back(nodeNum);
    for (int j =0;j<nodeNames.size();j++)
    {
        if ((!visiter[j])&&(matrixViewer[nodeNum][j]!=0))
            visitDFS(matrixViewer,nodeNum,j, visiter, size);
    }
    nodeOut.push_back(nodeNum);
    QList<QStandardItem *> standardItemsList_1,standardItemsList_2;
    for (int i = 0;i<nodeIn.size();i++)
        standardItemsList_1.append(new QStandardItem(nodeNames[nodeIn[i]]));
    //Построчная вставка полученный значений
    matrixPlacer->insertRow(matrixPlacer->rowCount(), standardItemsList_1);
    for (int i = 0;i<nodeOut.size();i++)
        standardItemsList_2.append(new QStandardItem(nodeNames[nodeOut[i]]));
    //Построчная вставка полученный значений
    matrixPlacer->insertRow(matrixPlacer->rowCount(), standardItemsList_2);
    QStringList headers;
    headers<<"Вход"<<"Выход";
    matrixPlacer->setVerticalHeaderLabels(headers);
    for (int i = 0 ;i<nodeNames.size();i++)
    {
        ui->tableView->setColumnWidth(i,1);
    }
    delete[] visiter;
}


//Рекурсивный обход графа в ширину
//ВАЖНО:nodeIn и nodeOut в данном случае являются очередью обхода и результатом обхода соответственно
void matrixViewer::visitBFS(int **matrixViewer, int row, int column, bool *visiter, int size)
{
    for (int j =0;j<size;j++)
    {
        if ((!visiter[j])&&(matrixViewer[column][j]!=0))
        {
            visiter[j] = true;
            nodeIn.push_back(j);
        }
    }
    nodeOut.push_back(nodeIn[row]);
    nodeIn.erase(nodeIn.cbegin());
}

void matrixViewer::BFS(int **matrixViewer, QStringList nodeNames, int nodeNum)
{
    bool *visiter;
    nodeIn.clear();
    nodeOut.clear();
    QStandardItemModel *matrixPlacer;
    matrixPlacer = new QStandardItemModel(this);
    ui->tableView->setModel(matrixPlacer);
    ui->tableView->clearSelection();
    visiter = new bool[nodeNames.size()];
    int size = 0;
    size = nodeNames.size();
    for (int i =0;i<nodeNames.size();i++)
            visiter[i]= false;
    //i- cтрока j- столбец
    visiter[nodeNum] = true;
    nodeIn.push_back(nodeNum);
    for (int j =0;j<nodeNames.size();j++)
    {
        if ((!visiter[j])&&(matrixViewer[nodeNum][j]!=0))
        {
            nodeIn.push_back(j);
            visiter[j]= true;
        }
    }
    while(!nodeIn.empty())
        visitBFS(matrixViewer, 0, nodeIn[0], visiter, size);
    QList<QStandardItem *> standardItemsList_1;
    for (int i = 0;i<nodeOut.size();i++)
        standardItemsList_1.append(new QStandardItem(nodeNames[nodeOut[i]]));
    //Построчная вставка полученный значений
    matrixPlacer->insertRow(matrixPlacer->rowCount(), standardItemsList_1);
    QStringList headers;
    headers<<"Обход";
    matrixPlacer->setVerticalHeaderLabels(headers);
    for (int i = 0 ;i<nodeNames.size();i++)
    {
        ui->tableView->setColumnWidth(i,1);
    }
    delete[] visiter;
}

matrixViewer::~matrixViewer()
{
    delete ui;
}
